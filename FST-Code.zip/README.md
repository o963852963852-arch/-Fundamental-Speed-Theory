# Fundamental Speed Theory (FST) - Numerical Implementation

Python implementation of the Fundamental Speed Theory for galactic dynamics.

## Installation

```bash
pip install -r requirements.txt